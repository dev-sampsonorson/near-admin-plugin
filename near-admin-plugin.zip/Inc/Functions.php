<?php
/**
 * Near Foundation Admin Plugin functions and definitions
 *
 *
 * @package Near Foundation
 */
